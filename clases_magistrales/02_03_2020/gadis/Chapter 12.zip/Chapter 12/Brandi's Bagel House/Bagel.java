/**
   This program creates an instance of the OrderCalculatorGUI class
   which displays the GUI for the Brandi's Bagel House application.
*/

public class Bagel
{
   public static void main(String[] args)
   {
      new OrderCalculatorGUI();
   }
}
